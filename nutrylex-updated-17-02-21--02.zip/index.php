<?php
$txtName = $_POST['txtName']; 
$txtEmail = $_POST['txtEmail'];
$txtMessage = $_POST['txtMessage'];

$subject = 'Nutrylex: Contact Us';
$to = 'testdhuni@gmail.com';
$from = 'testdhuni@gmail.com';


/*


$to = 'testdhuni@gmail.com';

$from = 'testdhuni@gmail.com';
*/

	if($txtname && $txtEmail) {
			$headers = "Name:   $txtName \r\n";
			$headers .= "Email: $txtEmail \r\n";
			$headers .= "Message: $txtMessage \r\n";
			
			$res = mail($to, $subject, $headers);
			if($res){
 			echo 'Your Message has been sent successfully!'; 
           header('location:contactus.php');
               // window.alert("sometext");
		} else {
			echo 'Something went wrong, Please Try Again.'; 
		}
	} else {
		echo 'All Fields are Required.';
	}
	?>